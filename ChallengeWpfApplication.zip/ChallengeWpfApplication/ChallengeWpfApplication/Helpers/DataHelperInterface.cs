﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace ChallengeWpfApplication.Helpers
{
    public interface IDataHelperInterface
    {
        XmlElement GetRoot(string path);
        XmlElement GetSubRoot(XmlElement elem, string path);
        XmlNodeList GetList(XmlElement elem, string path);
    }
}
