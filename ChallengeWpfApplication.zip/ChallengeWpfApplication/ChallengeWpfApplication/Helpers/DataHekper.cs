﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


namespace ChallengeWpfApplication.Helpers
{
    public class DataHekper : IDataHelperInterface 
    {
        private XmlDocument m_doc;
        public MainWindow MWin { get; set; }
        public DataHekper(XmlDocument doc)
        {
            m_doc = doc;
            
        }
        public XmlElement GetRoot(string path)
        {
            XmlElement root = (XmlElement)m_doc.SelectSingleNode(path);
            return root;
        }
        public XmlElement GetSubRoot(XmlElement elem, string path)
        {
            XmlElement result = (XmlElement)elem.SelectSingleNode(path);
            return result;
        }
        public XmlNodeList GetList(XmlElement elem, string path)
        {
            XmlNodeList result = elem.SelectNodes(path);
            return result;
        }
        
    }
    
}
